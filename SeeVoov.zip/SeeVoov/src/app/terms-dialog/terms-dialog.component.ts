import { Component, OnInit } from '@angular/core';
import { findSafariExecutable } from 'selenium-webdriver/safari';

@Component({
  selector: 'app-terms-dialog',
  templateUrl: './terms-dialog.component.html',
  styleUrls: ['./terms-dialog.component.css']
})
export class TermsDialogComponent implements OnInit {

   loading=true;
  constructor() {
    // this.loading=true;
   }

  ngOnInit() {
    setTimeout(()=>
    {
        this.loading=false;
    },1000);
  }
  
}
