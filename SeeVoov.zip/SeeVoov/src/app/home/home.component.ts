import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { DialogComponent } from '../dialog/dialog.component';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
import { MainDialogComponent } from '../main-dialog/main-dialog.component';
import { MainServiceService } from '../main-service.service';
import {AngularFireAuth}  from '@angular/fire/auth';
import { OwlOptions } from 'ngx-owl-carousel-o';
import { LoginService } from '../login.service';
import {Router,ActivatedRoute, Route, NavigationEnd} from   '@angular/router'; 
import {Title} from '@angular/platform-browser';
import { SetTitleService } from '../set-title.service';


// import {NgbDropdown} from '@ng-bootstrap/ng-bootstrap';
// import { DialogComponent } from '../dialog/dialog.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [ NgbCarouselConfig ]
})
export class HomeComponent implements OnInit {


  title="Plan Trips with Videos - SeeVoov";
  user=false;
  urlString: any[];
  user1: string;
  isSigned: any;
  constructor(config: NgbCarouselConfig,public dialog:MatDialog,
    public _mainService:MainServiceService,public afAuth:AngularFireAuth,
    public _loginService:LoginService,private router:Router,private route:ActivatedRoute,
    private _titleService:Title,private _setTitleService:SetTitleService) {
      config.interval = 2000;  
      config.wrap = true;  
      config.keyboard = false ;  
      config.pauseOnHover = true;   
  }

  


  
  printOption:string;
  selectedOption:string;
  selected:string;
  showHide=true;
  change_style_css:string;
  change_search_icon:string;
  opened=false;
  HideShow=false;
  HideClass:string;
  middle_hide=true;
  spinning_show=false;
  hideDrop:string;
  close=false;
  visiting_place:string;
  public slide_images = [

    '../../assets/images/home_page.jpg',
   
    '../../assets/images/home2.jpg',
   
    '../../assets/images/home3.jpg',
   
    '../../assets/images/home_page.jpg'
   
    ];
  // places:string[];
  places=[
    'Asia','Africa','Antartica','Kerala','Tamilnadu','Asia','Africa','Antartica','Kerala',
    'Tamilnadu','Asia','Africa','Antartica','Kerala','Tamilnadu'
  ];
  customOptions: OwlOptions = {
    loop: true,
    mouseDrag: false,
    touchDrag: false,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: ['<h5 class="fa fa-angle-left"></h5>', '<h5 class="fa fa-angle-right"></h5>'],
    responsive: {
      0: {
        items: 1
      },
      50: {
        items: 2
      },
       100: {
         items: 3
       },
       150: {
         items: 4
       },
      200: {
        items: 5
       },
       250: {
         items: 6
       }
      
    
    },
    nav: true
  }
 
  openDialog()
  {
  
    this.dialog.open(DialogComponent,{disableClose:true});
  }
  ngOnInit() {
    // this.selected=h;
    this.change_style_css='search_input';
    this.change_search_icon='search_input_i';
    
    this._mainService.change.subscribe(isSigned => {
      this.isSigned = isSigned;
      console.log(this._mainService.isSigned);
      if (this._mainService.isSigned) {
        this.user1 = this._mainService.getUser();
        console.log("user1"+this.user1);
        this.user = true;
        console.log("user"+this.user);
      }
    });


      this.hideDrop='dropdown-content';
      this._setTitleService.checkPageTitle();
  }
  change_style()
  {
    this.HideShow=true;
      this.showHide=false;
      this.change_style_css='toggle_style';
      this.change_search_icon='search_input_i2';
      this.HideClass='float_label';
  }
  closing_opened()
  {
       this.opened=false;
       this.HideShow=false;
       this.showHide=true;
       this.change_style_css="search_input";
       this.change_search_icon='search_input_i';
       this.router.navigate(['../../../']);
 
  }
  loading_module()
  {
    this.printOption=this.selectedOption;
    this._mainService.setOption(this.selectedOption);
    this.middle_hide=false;
    this.spinning_show=true;
    setTimeout(()=>
    {
      this.spinning_show=false;
       this.dialog.open(MainDialogComponent,{ disableClose: true });
       this.middle_hide=true;
    },5);
    this.visiting_place=this._mainService.getOption();
    this.router.navigate(['plan-trip',this.visiting_place,'choose-travel-kind'],{relativeTo:this.route});
    setTimeout(()=>
    {
        this.HideShow=false;
        this.showHide=true;
        this.change_style_css="search_input";
       this.change_search_icon='search_input_i';
       this.HideClass="";
    },20);
  }

  showDropdown()
  {
    this.close=false;
     this.hideDrop='dropdown-content_block';
  }
  hideDropdown()
  {
    this.close=true;
    this.hideDrop='dropdown-content';
  }
  logout()
  {
    this._mainService.logout();
    this.user = false;
    
}
}
  
