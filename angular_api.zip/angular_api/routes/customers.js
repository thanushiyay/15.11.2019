const mongoose=require('mongoose');
mongoose.connect('mongodb://localhost/SeeVoov')
   .then(()=> console.log("Connected to Mongo Db"))
   .catch(err=>console.error('Could not connect to mongo db',err));


 const courseSchema=new mongoose.Schema({
     firstName:String,
     lastName:String,
     email:String,
     password:String
 });
const Course=mongoose.model('Course',courseSchema);
async function createCourse()
{
    const course=new Course({
        firstName:'Thanushiya',
        lastName:'Yogaraj',
        email:'thanuyt@gmail.com',
        password:'ThanushiyaYogaraj'
    });
    
    
    const result=await course.save();
    console.log(result);
}


createCourse();
