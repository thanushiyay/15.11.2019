var mongoose=require('mongoose');
var express = require('express');
const Bcrypt = require('bcrypt');
const _=require('lodash');
var router = express.Router();
var CustomerService = require('../services/service.customer');
var  Customer=require('../models/model.customer');
let counter = 0;

router.post('/', async (req, res, next) =>
{
	const data = req.body;
	try
	{
		console.log("hiiii");
		await Customer.findOne({ email: data.email }, function (err, user) {
		if (user) 
			return res.status(400)
			  .send({ msg: 'The email address you have entered is already  another account.' });
		});
		

	
		data.password = Bcrypt.hashSync(data.password, 10);
		const customer=new Customer(_.pick(data,['firstName','lastName','email','password']));
         await customer.save();
        
		console.log(customer);
		return res.status(200).json(customer);
	}
	catch(err)
	{
		if (err.name === 'ValidationError')
		{
        	return res.status(400).json({ error: err.message });
		}

		// unexpected error	
		return next(err);
	}
});

//get Method
router.post('/check',async(req,res,next)=>
{
	 const body=req.body;
	 try
	 {
		  Customer.findOne({email:body.email},function(err,user)
		  {
				if(!user)
				{
					 return res.status(400).send("Invalid User and Password");
				}
				if(!Bcrypt.compareSync(body.password,user.password))
				{
					 return res.status(400).send("The password is incorrect");
				}
				else
				{
					
					console.log("Successs");
					console.log(user.firstName);
					const customer=new Customer(_.pick(user,['firstName','lastName','email','password']));
					console.log(customer);
					return res.status(200).json(customer);
				}
		  });
	 }
	 catch(err)
	{
		if (err.name === 'ValidationError')
		{
        	return res.status(400).json({ error: err.message });
		}

		// unexpected error	
		return next(err);
	}
    
});

module.exports = router;