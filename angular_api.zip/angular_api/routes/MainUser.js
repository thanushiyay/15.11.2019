const mongoose=require('mongoose');
const express=require('express');
const router=express.Router();
const CustomerModel=require('../models/model.customer');
router.post('/', async (req, res, next) =>
{
    let user = await CustomerModel.findOne({ email:req.body.email});
    if ( user ) return res.status(400).send('User already exists');
    // user = new CustomerModel(
    //     {
    //         firstName:req.body.firstName,
    //         lastName:req.body.lastName,
    //         email:req.body.email,
    //         password:req.body.password
    //     }
    // );
    let customer = new CustomerModel(data.firstName, data.lastName, data.email, data.password);
	await customer.save();
    customer.uid = 'c' + counter++;
		console.log(customer.uid + " " + customer.firstName);

		customers[customer.uid] = customer;
    // await user.save();
  

    return res.status(201).json({ customer: customer });
});
module.exports = router;